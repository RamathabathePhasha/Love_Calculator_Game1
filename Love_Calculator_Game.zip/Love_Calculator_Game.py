print("Welcome to love calculator")
Name1 =input("Please enter the first person'name:")
Name2 =input("Please enter the second person'name:")
FullNames= Name1+Name2
lower_case=FullNames.lower()

T=lower_case.count("T")
r=lower_case.count("r")
u=lower_case.count("u")
e=lower_case.count("e")

L=lower_case.count("L")
o=lower_case.count("o")
v=lower_case.count("v")
e=lower_case.count("e")

Percentage1=(T)+(r)+(u)+(e)
Percentage2=(L)+(o)+(v)+(e)

Percentage3=str(Percentage1)+str(Percentage2)
Percentage4=int(Percentage3)

if(Percentage4 >= 70):
    print("True Love",Percentage4)
elif(Percentage4 < 69 and Percentage4 > 50 ):
    print("Happiness",Percentage4)
elif(Percentage4 < 49 and Percentage4 > 40 ):
    print("Try again",Percentage4)    
else:
    print("Quit",Percentage4)